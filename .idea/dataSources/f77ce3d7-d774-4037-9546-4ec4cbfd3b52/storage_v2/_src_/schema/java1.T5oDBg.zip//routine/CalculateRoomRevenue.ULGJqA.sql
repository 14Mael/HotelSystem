create
    definer = root@localhost procedure CalculateRoomRevenue(IN p_start_time datetime, IN p_end_time datetime)
BEGIN
    -- 临时存储计算结果
    DROP TEMPORARY TABLE IF EXISTS temp_revenue;
    CREATE TEMPORARY TABLE temp_revenue (
        type_id VARCHAR(30),
        type_name VARCHAR(20),
        total_hours DECIMAL(10,2),
        total_revenue DECIMAL(10,2)
    );

    -- 计算每种房型的总小时数和总收益
    INSERT INTO temp_revenue
    SELECT 
        rt.type_id,
        rt.type_name,
        SUM(
            TIMESTAMPDIFF(
                MINUTE,
                GREATEST(r.checkin_time, p_start_time),
                LEAST(IFNULL(r.checkout_time, p_end_time), p_end_time)
            ) / 60.0
        ) AS total_hours,
        SUM(
            CASE 
                WHEN r.status = '已结算' THEN 
                    IFNULL((SELECT amount FROM cost WHERE record_id = r.record_id ORDER BY pay_time DESC LIMIT 1), 0)
                ELSE 
                    (TIMESTAMPDIFF(
                        MINUTE,
                        GREATEST(r.checkin_time, p_start_time),
                        LEAST(IFNULL(r.checkout_time, p_end_time), p_end_time)
                    ) * (rt.`price` / 1440))
            END
        ) AS total_revenue
    FROM 
        record r
    JOIN 
        room rm ON r.room_num = rm.room_num
    JOIN 
        room_type rt ON rm.type_id = rt.type_id
    WHERE 
        (
            (r.checkin_time <= p_end_time) 
            AND 
            (r.checkout_time >= p_start_time OR r.checkout_time IS NULL)
        )
    GROUP BY 
        rt.type_id, rt.type_name;

    -- 返回结果集
    SELECT 
        IFNULL(type_id, 'N/A') AS '类型编号',
        IFNULL(type_name, 'N/A') AS '房型',
        IFNULL(ROUND(total_hours, 2), 0) AS '入住小时数',
        IFNULL(ROUND(total_revenue, 2), 0) AS '费用合计'
    FROM temp_revenue
    WHERE total_hours > 0 OR total_revenue > 0;
    
    -- 如果没有数据，返回提示行
    IF ROW_COUNT() = 0 THEN
        SELECT 
            '无数据' AS '类型编号',
            '请检查时间范围' AS '房型',
            0 AS '入住小时数',
            0 AS '费用合计';
    END IF;
    
    -- 清理临时表
    DROP TEMPORARY TABLE IF EXISTS temp_revenue;
END;

