create definer = root@localhost trigger checkout_update_status
    before update
    on record
    for each row
BEGIN
    -- 关键点：通过 SET NEW.checkout_time 修改当前行，而非触发新的 UPDATE
    IF OLD.status = '已入住' AND NEW.status = '已结算' THEN
        SET NEW.checkout_time = NOW();
    END IF;
    
    -- 更新客房状态（不涉及 record 表，安全）
    IF OLD.status != '已结算' AND NEW.status = '已结算' THEN
        UPDATE room SET status = '空闲' WHERE room_num = NEW.room_num;
    END IF;
END;

