create definer = root@localhost trigger checkin_update_status
    before insert
    on record
    for each row
BEGIN
    SET NEW.checkin_time = NOW();  -- 直接修改待插入的行，不触发新的 INSERT/UPDATE
    UPDATE room SET status = '已入住' WHERE room_num = NEW.room_num;  -- 操作其他表，安全
END;

