create definer = root@localhost view spare_rooms as
select `java1`.`room`.`room_num`       AS `room_num`,
       `java1`.`room`.`status`         AS `status`,
       `java1`.`room_type`.`type_name` AS `type_name`,
       `java1`.`room_type`.`price/day` AS `Price/day`
from (`java1`.`room` join `java1`.`room_type` on ((`java1`.`room_type`.`type_id` = `java1`.`room`.`type_id`)))
where (`java1`.`room`.`status` = '空闲');

