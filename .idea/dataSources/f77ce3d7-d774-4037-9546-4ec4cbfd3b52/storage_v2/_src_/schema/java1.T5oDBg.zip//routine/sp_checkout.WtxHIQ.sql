create
    definer = root@localhost procedure sp_checkout(IN p_record_id int)
BEGIN
    DECLARE v_room_num VARCHAR(20);
    DECLARE v_customer_id INT;
    DECLARE v_checkin_time DATETIME;
    DECLARE v_deposit DECIMAL(10,2);
    DECLARE v_base_fee DECIMAL(10,2);
    DECLARE v_total_fee DECIMAL(10,2);
    DECLARE v_price_per_day DECIMAL(10,2);  
    DECLARE v_checkout_time DATETIME;
    DECLARE v_minutes INT;
    
    -- 异常处理：回滚并抛出错误
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- 设置退房时间为当前时间
    SET v_checkout_time = NOW();

    -- 1. 查询入住记录
    SELECT 
        room_num, 
        customer_id, 
        checkin_time
    INTO 
        v_room_num, 
        v_customer_id, 
        v_checkin_time
    FROM record 
    WHERE record_id = p_record_id 
      AND status = '已入住';

    -- 若记录无效，抛出错误
    IF v_room_num IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '无效的入住记录';
    END IF;

    -- 2. 查询房型单价
    SELECT 
        `price`  
    INTO 
        v_price_per_day
    FROM room_type 
    JOIN room ON room_type.type_id = room.type_id
    WHERE room.room_num = v_room_num;

    -- 3. 查询客户押金（无值时默认 0）
    SELECT COALESCE(deposit, 0) INTO v_deposit 
    FROM customer 
    WHERE customer_id = v_customer_id;

    -- 4. 阶梯式计算费用（按分钟计算）
    SET v_minutes = TIMESTAMPDIFF(MINUTE, v_checkin_time, v_checkout_time);
    
    SET v_base_fee = CASE
        WHEN v_minutes <= 120 THEN v_price_per_day * 0.25  -- 2小时内25%
        WHEN v_minutes <= 240 THEN v_price_per_day * 0.5   -- 4小时内50%
        WHEN v_minutes <= 1440 THEN v_price_per_day        -- 24小时内100%
        ELSE v_price_per_day * CEIL(v_minutes/1440.0)     -- 超过24小时按整天计算
    END;
    
    -- 计算总费用（基础费用减去押金，但不低于0）
    SET v_total_fee = GREATEST(v_base_fee - v_deposit, 0);

    -- 5. 插入费用记录
    INSERT INTO cost (record_id, amount, pay_time) 
    VALUES (p_record_id, v_total_fee, v_checkout_time);

    -- 6. 更新入住记录状态
    UPDATE record 
    SET checkout_time = v_checkout_time,
        total_cost = v_total_fee,
        status = '已结算'
    WHERE record_id = p_record_id;

    -- 7. 扣除押金（如果押金未完全抵扣费用）
    IF v_deposit > 0 AND v_deposit > v_base_fee THEN
        UPDATE customer 
        SET deposit = deposit - v_base_fee  
        WHERE customer_id = v_customer_id;
    ELSEIF v_deposit > 0 THEN  -- 修改了这里，从ELSIF改为ELSEIF
        UPDATE customer 
        SET deposit = 0  
        WHERE customer_id = v_customer_id;
    END IF;

    COMMIT;
END;

